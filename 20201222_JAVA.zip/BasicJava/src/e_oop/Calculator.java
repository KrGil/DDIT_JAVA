package e_oop;

public class Calculator {
	
	//계산기
	//계산해주는 메서드 생성
	//+ - * / % 총 5개의 메서드. 2개의 파라미터를 받고 return
//	int sum(int a, int b){
//		return a+b;
//	}
//
//	long times(long a, int b){
//		return (long)(a*b);
//	}
//	double divide(double times, int b){
//		return times/b;
//	}
//	int rest(int a, int b){
//		return a%b;
//	}
//	int rest(double a, double b){
//		return (int) (a%b);
//	}
//	double minus(double a, int b) {
//		return a-b;
//		
//	}
	
	//쌤이 한거
	double sum(double a, double b){
		return a+b;
	}double times(double a, double b){
		return a*b;
	}double divide(double a, double b){
		return a/b;
	}
	double rest(double a, double b){
		return a%b;
	}
	double sub(double a, double b){
		return a-b;
	}
}
