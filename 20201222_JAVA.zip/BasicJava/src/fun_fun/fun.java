package fun_fun;

public class fun {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lunch_total total = new Lunch_total();
		System.out.println(total.cal(30, 3500));
		System.out.println(total.result(10,3300));
		
	}

}
