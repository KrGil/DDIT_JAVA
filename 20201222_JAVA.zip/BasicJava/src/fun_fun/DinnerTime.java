package fun_fun;

public class DinnerTime {
	
	public static void main(String[] args){
		//저녁메뉴
		Dinner_class.dinner();
		//사다리
//		Sadari.sadari();
	}
	
}
