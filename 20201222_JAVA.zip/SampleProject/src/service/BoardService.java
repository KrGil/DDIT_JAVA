package service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import util.ScanUtil;
import util.View;
import controller.Controller;
import dao.BoardDao;

public class BoardService {
	//싱글톤 패턴으로 만듦.
	private static BoardService instance;
	private BoardService(){} 
	public static BoardService getInstance(){
		if(instance == null){
			instance = new BoardService();
		}
		return instance;
	}
	
	private BoardDao boardDao = BoardDao.getInstance();
	private int currentBoardNo;
	
	
	public int boardList() {
		List<Map<String, Object>> boardList = boardDao.selectBoardList();
		Controller.size = boardList.size();
		System.out.println("============================================");
		System.out.println("번호\t제목\t작성자\t작성일");
		System.out.println("============================================");
		for(int i =0; i < boardList.size(); i ++){
			Map<String, Object> board = boardList.get(i);
			System.out.println(board.get("BOARD_NO") + "\t"
					+ board.get("TITLE") + "\t"
					+ board.get("USER_NAME") + "\t"
					+ board.get("REG_DATE"));
		}
		System.out.println("============================================");
		System.out.println("1.조회\t2.등록 \t0.로그아웃");
		System.out.println("입력> ");
		int input = ScanUtil.nextInt();
		switch (input){
			case 1:
				System.out.println("게시글 번호 입력>");
				currentBoardNo = ScanUtil.nextInt();
				return View.BOARD_VIEW;
			case 2:
				return View.BOARD_INSERT_FORM;			
			case 0:
				Controller.loginUser = null;
				return View.HOME;
		}
		return View.BOARD_LIST;
	}
	public int boardView() {
		Map<String, Object> selectboardView = boardDao.selectBoardView(currentBoardNo);
		System.out.println("number : "+currentBoardNo);
		System.out.println("============================================");
		System.out.println("번호 : "+selectboardView.get("BOARD_NO"));
		System.out.println("제목 : "+selectboardView.get("TITLE"));
		System.out.println("작성자 : "+selectboardView.get("USER_NAME"));
		System.out.println("작성일 : "+selectboardView.get("REG_DATE"));
		System.out.println("============================================");
		
		return View.BOARD_LIST;
	}
	public int boardInsertForm() {
		System.out.println("제목 >");
		String title = ScanUtil.nextLine();
		System.out.println("내용 >");
		String content = ScanUtil.nextLine();
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("TITLE", title);
		param.put("CONTENT", content);
		param.put("USER_ID", Controller.loginUser.get("USER_ID"));
		
		System.out.println(param.get("TITLE"));
		System.out.println(param.get("CONTENT"));
		System.out.println(param.get("USER_ID"));
		
		int result = boardDao.insertForm(param);
		if(0 < result){
			System.out.println("글 작성 성공");
		}else{
			System.out.println("글 작성 실패");
		}
		return View.BOARD_LIST;
	}
}
