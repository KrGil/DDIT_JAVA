package util;

public class View {
	//어떤 화면이 있는지 정의
	public static final int HOME = 0; 
	public static final int LOGIN = 1;
	public static final int JOIN = 2;
	public static final int BOARD_LIST = 3;
	public static final int BOARD_VIEW = 4;
	public static final int BOARD_INSERT_FORM = 5;
	
	
}
