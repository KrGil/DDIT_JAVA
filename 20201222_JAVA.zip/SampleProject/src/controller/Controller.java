package controller;

import java.util.Map;

import service.BoardService;
import service.UserService;
import util.ScanUtil;
import util.View;

public class Controller {

	public static void main(String[] args) {

	/*
	 * 발표순서 : 조 소개 > 주제 소개 > 주제 선정 배경 > 메뉴 구조  > 시연
	 * 발표인원 : 발표자 1명, ppt 및 시연 도우미 1명
	 * 
	 * Controller : 화면 이동
	 * Service : 화면 기능
	 * Dao : 쿼리 작성
	 * 
	 */
		new Controller().start();
	}
	public static Map<String, Object> loginUser; //이 값이 변했다는 것은 로그인 해 있다는 뜻.변하지 않으면 아무도 로그인 해 있지 않다.
	public static int size;
	private UserService userService = UserService.getInstance();
	private BoardService boardService = BoardService.getInstance();

	
	private void start(){
		int view = View.HOME; //시작화면
		while(true){
			switch(view){ //보여줄 화면
				case View.HOME : 
					view = home(); break;
				case View.LOGIN : 
					view = userService.login(); break;
				case View.JOIN : 
					view = userService.join(); break;
				case View.BOARD_LIST : 
					view = boardService.boardList(); break; //user는 사용자를 위한 것이기에.
				case View.BOARD_VIEW :
					view = boardService.boardView(); break;
				case View.BOARD_INSERT_FORM : 
					view = boardService.boardInsertForm(); break;
				
			}
		}
	}
	
	private int home(){
		System.out.println("------------------------------------");
		System.out.println("1.로그인 \t2.회원가입\t0.프로그램 종료");
		System.out.println("------------------------------------");
		System.out.println("번호입력 >");
		
		int input = ScanUtil.nextInt();
		switch(input){
			case 1: return View.LOGIN;
			case 2: return View.JOIN;
			case 3: 
				System.out.println("프로그램이 종료되었습니다.");
				System.exit(0);
			break;
		}
		return View.HOME;
	}
}
