package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import controller.Controller;
import util.JDBCUtil;

public class BoardDao {
	//싱글톤 패턴으로 만듦.
	private static BoardDao instance;
	private BoardDao(){} 
	public static BoardDao getInstance(){
		if(instance == null){
			instance = new BoardDao();
		}
		return instance;
	}
	
	private JDBCUtil jdbc = JDBCUtil.getInstance();
	
	public List<Map<String, Object>> selectBoardList(){
		String sql = "SELECT A.BOARD_NO, A.TITLE, A.CONTENT, B.USER_NAME, A.REG_DATE"
				+ " FROM TB_JDBC_BOARD A"
				+ " LEFT OUTER JOIN TB_JDBC_USER B"
				+ " ON A.USER_ID = B.USER_ID"
				+ " ORDER BY A.BOARD_NO DESC";
		return jdbc.selectList(sql);
	}
	public Map<String, Object> selectBoardView(int param){
		String sql = "SELECT A.BOARD_NO, A.TITLE, A.CONTENT, B.USER_NAME, A.REG_DATE"
				+ " FROM TB_JDBC_BOARD A"
				+ " LEFT OUTER JOIN TB_JDBC_USER B"
				+ " ON A.USER_ID = B.USER_ID"
				+ " WHERE A.BOARD_NO = ?"
				+ " ORDER BY A.BOARD_NO DESC";
				
		List<Object> p = new ArrayList<>();
		p.add(param);
		return jdbc.selectOne(sql, p);
	}
	public int insertForm(Map<String, Object> param){
		String sql = "INSERT INTO TB_JDBC_BOARD VALUES (?,?,?,?,SYSDATE)";
		List<Object> p = new ArrayList<>();
		
		p.add(Controller.size+1);
		p.add(param.get("TITLE"));
		p.add(param.get("CONTENT"));
		p.add(param.get("USER_ID"));
		
		System.out.println("1 : "+p.get(0));
		System.out.println("2 : "+p.get(1));
		System.out.println("3 : "+p.get(2));
		System.out.println("4 : "+p.get(3));
		
		return jdbc.update(sql, p);
	}
}
	